<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AABJ E-mail</title>
    <link rel="stylesheet" href="emailstyle.css">
    <!-- bootstrap cdn link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="topnav">
        
        <a href="front.php" style="margin-right: 10px; margin-top: 7px; font-size: 20px"><i class="fa fa-home"> Home</i></a>
        
        <a href="chat1front.php" style="margin-top: 7px; font-size: 20px"><i class="fa fa-comments"> Chat</i></a>

        <a href="aabj1front.php" style="margin-top: 7px; font-size: 20px"><i class="fa fa-search"> Search</i></a>
        
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 mail-form">
                <h2 class="text-center">AABJ E-mail</h2>
                <p class="text-center">Send mail to anyone from localhost.</p>
                <!-- starting php code -->
                <?php
                    //first we leave this input field blank
                    $sendto = "";
                    //if user click the send button
                    if(isset($_POST['send'])){
                        //access user entered data
                       $sendto = $_POST['email'];
                       $subject = $_POST['subject'];
                       $message = $_POST['message'];
                       $sender = "From: nav8abhi@gmail.com";
                       //if user leave empty field among one of them
                       if(empty($sendto) || empty($subject) || empty($message)){
                           ?>
                           <!-- display an alert message if one of them field is empty -->
                            <div class="alert alert-danger text-center">
                                <?php echo "All inputs are required!" ?>
                            </div>
                           <?php
                        }else{
                            // PHP function to send mail
                           if(mail($sendto, $subject, $message, $sender)){
                            ?>
                            <!-- display a success message if once mail sent sucessfully -->
                            <div class="alert alert-success text-center">
                                <?php echo "Your mail successfully sent to $sendto"?>
                            </div>
                           <?php
                           $sendto = "";
                           }else{
                            ?>
                            <!-- display an alert message if somehow mail can't be sent -->
                            <div class="alert alert-danger text-center">
                                <?php echo "Failed while sending your mail!" ?>
                            </div>
                           <?php
                           }
                       }
                    }
                ?> <!-- end of php code -->
                <form action="email.php" method="POST">
                    <div class="form-group">
                        <input class="form-control" name="email" type="email" placeholder="Send To" value="<?php echo $sendto ?>">
                    </div>
                    <div class="form-group">
                        <input class="form-control" name="subject" type="text" placeholder="Subject">
                    </div>
                    <div class="form-group">
                        <textarea cols="30" rows="5" class="form-control textarea" name="message" placeholder="Compose your message.."></textarea>
                    </div>
                    <div class="form-group">
                        <input class="form-control button btn-primary" type="submit" name="send" value="Send" placeholder="Subject">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>